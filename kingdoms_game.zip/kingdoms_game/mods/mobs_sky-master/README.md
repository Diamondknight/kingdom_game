A few sky critters ported from other mob frameworks to "Mobs-Redo".

License information for the models and textures can be found inside
the respective folders.
