# Anvil

_An anvil mod for minetest_

This mod is still in a WIP phase, so expect changes in the future :)

Basing on the GPLv3 licensed anvil in the [cottages mod](https://forum.minetest.net/viewtopic.php?id=5120) from Sokomine ([github link](https://github.com/Sokomine/random_buildings/master/cottages)).

Improved by est31.

License: GPLv3
