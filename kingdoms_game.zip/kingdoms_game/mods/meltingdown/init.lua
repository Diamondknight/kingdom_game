minetest.register_craft({
output = "default:steel_ingot 9",
type = "cooking",
cooktime = 25,
recipe = "default:steelblock"
})

minetest.register_craft({
output = "default:gold_ingot 9",
type = "cooking",
cooktime = 25,
recipe = "default:goldblock"
})

minetest.register_craft({
output = "default:copper_ingot 9",
type = "cooking",
cooktime = 25,
recipe = "default:copperblock"
})

minetest.register_craft({
output = "default:gold_ingot",
type = "cooking",
cooktime = 25,
recipe = "soundblocks:gong"
})

minetest.register_craft({
output = "default:bronze_ingot 9",
type = "cooking",
cooktime = 25,
recipe = "default:bronzeblock"
})


minetest.register_craft({
output = "default:gold_ingot 5",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:trumpet"
})


minetest.register_craft({
output = "default:gold_ingot 5",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:fanfare"
})

minetest.register_craft({
output = "default:gold_ingot 5",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:bell_gold"
})

minetest.register_craft({
output = "default:steel_ingot 5",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:bell"
})

minetest.register_craft({
output = "default:gold_ingot 5",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:goldbellitem"
})

minetest.register_craft({
output = "default:steel_ingot",
type = "cooking",
cooktime = 15,
recipe = "soundblocks:ironbellitem"
})



minetest.register_craft({
	type = "fuel",
	recipe = "default:pick_wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:axe_wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:sword_wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "default:shovel_wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "soundblocks:smallhorn",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "lottweapons:wood_battleaxe",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "lottweapons:wood_warhammer",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "lottweapons:wood_spear",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "lottweapons:wood_dagger",
	burntime = 7,
})

