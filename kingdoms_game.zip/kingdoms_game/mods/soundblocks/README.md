#lottmusic
This mod adds instruments to lott.

##License
###Sound
Sound file (lottmusic_trumpet.ogg): CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/legalcode)  
Published by "Harbour11" (https://freesound.org/people/Harbour11/sounds/194625/)  
No changes were made.

Sound file (BellSmall.ogg) CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/legalcode)  
Published by "HerbertBoland" (http://freesound.org/people/HerbertBoland/sounds/30160/)  
No changes were made.


Sound file (lottmusic_fanfare.ogg) CC BY 3.0 (http://creativecommons.org/licenses/by/3.0/legalcode)  
Published by "neonaeon" (http://freesound.org/people/neonaeon/sounds/49477/)  
No changes were made.

###Texture
Texture (lottmusic_trumpet.png): CC0  
Made by Thomas S.

Texture (lottmusic_bellitem.png): CC0  
Made by Thomas S.

Texture (lottmusic_fanfare.png): CC0  
Made by Thomas S.
