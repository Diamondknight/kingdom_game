local function campfire_timer(pos)
	local node = minetest.get_node(pos)
	local timer = minetest.get_node_timer(pos)
	if node.name ~= "campfire:campfire" and node.name ~= "campfire:campfire_active" then
		timer:stop()
		return false
	end
	local meta = minetest.get_meta(pos)
	local time_remain = meta:get_int("time_remain")
	local time_total = meta:get_int("time_total")
	if time_remain <= 0 then
		local inv = meta:get_inventory()
		local fuel_list = inv:get_list("fuel")
		local fuel,leftover = minetest.get_craft_result({method = "fuel",width = 1,items = fuel_list})
		if fuel.time > 0 then
			time_total = fuel.time
			meta:set_int("time_total",time_total)
			time_remain = time_total
			inv:set_stack("fuel",1,leftover.items[1])
		end
	end
	if time_remain > 0 then
		meta:set_string("infotext","")
		meta:set_int("time_remain",time_remain - 1)
		if node.name == "campfire:campfire" then
			node.name = "campfire:campfire_active"
			minetest.swap_node(pos,node)
		end
		local part = (time_remain / time_total) * 100
		local fs = "size[8,9]"..
			"list[context;fuel;3.5,2;1,1;]"..
			"list[current_player;main;0,5;8,4;]"..
			"listring[]"..
			"image[3.5,1;1,1;default_furnace_fire_bg.png^[lowpart:"..part..":default_furnace_fire_fg.png]"
		meta:set_string("formspec",fs)
	else
		meta:set_string("infotext","Put more wood on the fire!")
		meta:set_int("time_remain",0)
		if node.name == "campfire:campfire_active" then
			node.name = "campfire:campfire"
			minetest.swap_node(pos,node)
			timer:stop()
			local fs = "size[8,9]"..
				"list[context;fuel;3.5,2;1,1;]"..
				"list[current_player;main;0,5;8,4;]"..
				"listring[]"..
				"image[3.5,1;1,1;default_furnace_fire_bg.png]"
			meta:set_string("formspec",fs)
			return false
		end
	end
	return true
end

minetest.register_node("campfire:campfire", {
	description = "Campfire",
	drawtype = "plantlike",
	tiles = {"campfire_campfire.png"},
	walkable = false,
	paramtype = "light",
	sunlight_propogates = true,
	groups = {oddly_breakable_by_hand = 3},
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("infotext","Put some wood on the fire!")
		local fs = "size[8,9]"..
			"list[context;fuel;3.5,2;1,1;]"..
			"list[current_player;main;0,5;8,4;]"..
			"listring[]"..
			"image[3.5,1;1,1;default_furnace_fire_bg.png]"
		meta:set_string("formspec",fs)
		local inv = meta:get_inventory()
		inv:set_size("fuel",1)
	end,
	on_metadata_inventory_put = function(pos)
		minetest.get_node_timer(pos):start(1)
	end,
	on_timer = campfire_timer,
	can_dig = function(pos)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("fuel")
	end
})

minetest.register_node("campfire:campfire_active", {
	drawtype = "plantlike",
	tiles = {{name="campfire_campfire_active.png",animation={type="vertical_frames", aspect_w=16, aspect_h=16, length=1.5}}},
	drop = "campfire:campfire",
	walkable = false,
	paramtype = "light",
	light_source = 10,
	sunlight_propogates = true,
	groups = {oddly_breakable_by_hand = 3,not_in_creative_inventory = 1},
	on_timer = campfire_timer,
	can_dig = function(pos)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		return inv:is_empty("fuel")
	end
})

minetest.register_alias("campfire:campfire","campfire:campfire")
minetest.register_alias("campfire:campfire_active","campfire:campfire_active")

minetest.register_craft({
	output = "campfire:campfire 1",
	recipe = {
			{"","default:stick",""},
			{"default:stick","","default:stick"}
	}
})
