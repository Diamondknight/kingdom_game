minetest.register_craft({
output = "default:coal_lump",
type = "cooking",
cooktime = 15,
recipe = "group:tree"
})