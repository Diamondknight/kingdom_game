Creatures MOB-Engine
====================
Copyright (c) 2015-2016 BlockMen <blockmen2015@gmail.com>

Version: 2.0.2


This mod provides an engine, that handles the base function for MOB in Minetest.
It offers an easy way to register MOB and allows to custom handling for the needs
of each mob. This engine aims to be a solid base, that has a good balance between
performance and functionality.
See API.txt for more informations on how to use this engine for mobs.


License:
~~~~~~~~
Code:
(c) Copyright 2015-2016 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(textures and other media):
(c) Copyright (2014-2016) BlockMen; CC-BY-SA 3.0

Github:
~~~~~~~
https://github.com/BlockMen/cme/creatures
