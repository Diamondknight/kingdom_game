Player Textures Mod for Minetest
================================

This mod allows players to use different textures. Just place the texture in
the player_textures/textures/ folder like this:
player_<player_name>.png
and the player with the name <player_name> will have this textures.

License of source code:
-----------------------
WTFPL

License of the example textures:
--------------------------------
WTFPL
