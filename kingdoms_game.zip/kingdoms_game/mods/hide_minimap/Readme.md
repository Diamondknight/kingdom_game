##hide_minimap: a Minetest mod.

This mod allows server admins to hide the minimap to normal players, and allow certain players to use it with the minimap priv.

Its main purpose is for extreme survival servers, please do not use it unless you really need to, as the minimap is an awesome feature! (If this mod becomes used on too many servers, I may have to add a check for my name into the code, which allows me to always use it...!) However, on extreme survival servers, where the chief purpose is survival, it serves a point.

*Depends:* None!

*License:* MIT
